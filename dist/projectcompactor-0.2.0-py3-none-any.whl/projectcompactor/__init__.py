# projectcompactor/__init__.py

from .generator import ProjectCompactor

__all__ = ['ProjectCompactor']
